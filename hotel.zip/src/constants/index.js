export const API_URL = 'http://192.168.64.2/demo_hotel/public/api/';
